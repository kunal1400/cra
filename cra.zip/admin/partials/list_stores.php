<h2>All Stores</h2>
<hr/>
<form action="" method="post">
  <table>
    <tbody>
      <tr>
        <td>
          <button type="submit" class="button button-primary">Delete All</button>
        </td>
      </tr>
    </tbody>
  </table>
  <hr/>
  <table class="wp-list-table widefat fixed striped">
    <thead>
      <th width="5%"><input type="checkbox" id="selectAllStore" /></th>
      <th width="10%">Store ID</th>
      <th width="20%">Name</th>
      <th width="25%">Address</th>
      <th width="15%">Expiration</th>
      <th width="15%">Last Update</th>
      <th width="10%">Action</th>
    </thead>
    <tbody>
      <?php
        foreach ($results as $i => $store) {
          $storeUrl = admin_url().'admin.php?page=add_cra_listings&storeId='.$store['StoreID'];
          if( $i % 2 == 0 ) {
            $className = "alternate";
          }
          else {
            $className = "";
          }
          echo '<tr class="'.$className.'">
            <td><input type="checkbox" name="storeToDelete[]" value="'.$store['StoreID'].'" /></td>
            <td>'.$store['StoreID'].'</td>
            <td><a href="'.$storeUrl.'" >'.$store['Name'].'</a></td>
            <td>'.$store['Address'].'</td>
            <td>'.$store['expiration'].'</td>
            <td>'.$store['LastUpdate'].'</td>
            <td>
              <a class="button button-info" href="'.$storeUrl.'">Edit</a>
              <a class="button button-danger" href="'.admin_url().'admin.php?page=cra_settings&deleteStoreId='.$store['StoreID'].'">Delete</a>
            </td>
          </tr>';
        }
      ?>
    </tbody>
  </table>
  <div class="tablenav" style="width: 99%;text-align: center;">
    <div class="tablenav-pages" style="margin: 1em 0;float: none;font-size: 18px;"><?php echo $page_links ?></div>
  </div>
</form>
