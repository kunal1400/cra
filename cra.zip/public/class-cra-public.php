<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @link       https://github.com/kunal1400/cra.git
 * @since      1.0.0
 *
 * @package    Cra
 * @subpackage Cra/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the public-facing stylesheet and JavaScript.
 *
 * @package    Cra
 * @subpackage Cra/public
 * @author     Kunal Malviya <mark@bilmartech.com>
 */
class Cra_Public {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of the plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Cra_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Cra_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/cra-public.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Cra_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Cra_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/cra-public.js', array( 'jquery' ), $this->version, false );

	}

	public function get_full_table_data($tableName) {
		global $wpdb;
		$storeTableName = $wpdb->prefix.$tableName;
		return $wpdb->get_results("SELECT * FROM $storeTableName", ARRAY_A);
	}

	/**
	* Show Listings shortcode callback
	**/
	public function show_listings_cb() {
		global $wpdb;
		$storeTableName = $wpdb->prefix."stores";
		$todays_date = date("Y-m-d");
		$State = "AL";
		$City = "";
		$Zip = "";
		$RadiusMiles = 10;
		$Cat = 1;
		$findzip = null;
		$returnString = "";

		// Getting variables from query string and POST data
		if ( array_key_exists('_submit_check', $_POST) ) {
			$State = $_POST['State'];
			$City = $_POST['City'];
			$Zip = $_POST['Zip'];
			$RadiusMiles = $_POST['RadiusMiles'];
			$Cat = $_POST['Category'];
		}
		else {
			if (isset($_GET['State'])) {
				$State = $_GET['State'];
			}
			if (isset($_GET['City'])) {
				$City = $_GET['City'];
			}
			if (isset($_GET['Zip'])) {
				$Zip = $_GET['Zip'];
			}
			if (isset($_GET['RadiusMiles'])) {
				$RadiusMiles = $_GET['RadiusMiles'];
			}
			if (isset($_GET['Category'])) {
				$Cat = $_GET['Category'];
			}
		}

		$returnString .= $this->searchHtml( $RadiusMiles, $State, $City, $Zip );

		// If this is a City Search continue
		if ( $City != "" || $Zip != "" ) {
			/*** Open our recordset - THIS DB NOT GIVEN BY CLIENT **/
			if ( !empty($City) && !empty($State) ) {
				// $query = "select * FROM ".$wpdb->prefix."zipcodes WHERE City = '$City' and State = '$State' LIMIT 1";
				$query = "select * FROM $storeTableName WHERE City = '$City' and State = '$State' LIMIT 1";
				$Newzip = $wpdb->get_row($query, ARRAY_A);
				$findzip = $Newzip;
				$searchzip = $Newzip['Zip'];
				$ZipLat = $Newzip['Latitude'];
				$ZipLong = $Newzip['Longitude'];
			}
			else if( !empty($Zip) ) {
				// $query = "select * FROM ".$wpdb->prefix."zipcodes WHERE ZIP = '$Zip' LIMIT 1";
				$query = "select * FROM $storeTableName WHERE Zip = '$Zip' LIMIT 1";
				$Newzip = $wpdb->get_row($query, ARRAY_A);
				$findzip = $Newzip;
				$searchzip = $Newzip['Zip'];
				$ZipLat = $Newzip['Latitude'];
				$ZipLong = $Newzip['Longitude'];
			}

			//BUILD MAP
			if( $findzip == null ) {
				$returnString = "<div class=smallbold align=center><br>We were unable to locate this City in our database.<br>Please verify the City is spelled correctly and you have the correct state.</div>";
			}
			else {
				if ( !empty($Cat) ) {
					$sql = "SELECT Name, Address, Address2, City, State, Zip, Phone, Website, Discount, Category, Longitude, Latitude, featured, pastfeatured, (3959*acos(cos(radians($ZipLat))*cos(radians(Latitude))*cos(radians(Longitude)-radians($ZipLong))+sin(radians($ZipLat))*sin(radians(Latitude)))) AS distance FROM $storeTableName WHERE Category = '$Cat' and (expiration >= '$todays_date' OR Status = 'Active') HAVING distance < $RadiusMiles ORDER BY distance";
					$GetStores = $wpdb->get_results($sql, ARRAY_A);
				}
				else {
					$sql = "SELECT Name, Address, Address2, City, State, Zip, Phone, Website, Discount, Category, Latitude, Longitude, featured, pastfeatured, (3959*acos(cos(radians($ZipLat))*cos(radians(Latitude))*cos(radians(Longitude)-radians($ZipLong))+sin(radians($ZipLat))*sin(radians(Latitude)))) AS distance FROM $storeTableName WHERE (expiration >= '$todays_date' OR Status = 'Active') HAVING distance <= $RadiusMiles ORDER BY distance";
					$GetStores = $wpdb->get_results($sql, ARRAY_A);
				}
			}
			$returnString .= $this->listingsHtml($GetStores, 'cityOrZipSearch');
		}
		// This is a State Only Search
		else {
			if ($Cat <> "") {
				$GetStores = $wpdb->get_results("select * FROM $storeTableName WHERE State = '$State' and (expiration >= '$todays_date' OR Status = 'Active') and Category='$Cat' ORDER BY NAME", ARRAY_A);
			}
			else {
				$GetStores = $wpdb->get_results("select * FROM $storeTableName WHERE State = '$State' and (expiration >= '$todays_date' OR Status = 'Active') ORDER BY NAME", ARRAY_A);
			}
			if( count($GetStores) == 0 ) {
				$returnString .= "<div class=smallbold align=center><br>There are currently no Great American Cigar Shops&trade; in this state.<br /><a href=http://www.cigarrights.org/membership_GACS.php>Join now and be the first!</a></div>";
			}
			else {}
			$returnString .= $this->listingsHtml($GetStores, 'stateSearch');
		}
		return $returnString;
	}

	/**
	* Format phone function
	**/
	function format_phone($phone) {
		$phone = preg_replace("/[^0-9]/", "", $phone);
		if(strlen($phone) == 7)
			return preg_replace("/([0-9]{3})([0-9]{4})/", "$1-$2", $phone);
		elseif(strlen($phone) == 10)
			return preg_replace("/([0-9]{3})([0-9]{3})([0-9]{4})/", "($1) $2-$3", $phone);
		else
			return $phone;
	}

	/**
	* Search result container
	**/
	function listingsHtml($stores, $type) {
		$str = '<div class="searchContainer '.$type.'"><div class="searchContainerRow">';
		$CatPic = null;
		foreach ($stores as $count => $ShowStores) {
			$Name = $ShowStores['Name'];
			$Address = $ShowStores['Address'];
			$Address2 = $ShowStores['Address2'];
			$City = $ShowStores['City'];
			$State = $ShowStores['State'];
			$ListingZip = $ShowStores['Zip'];
			$Phone = $ShowStores['Phone'];
			$Website = $ShowStores['Website'];
			$Discount = $ShowStores ['Discount'];
			$Category = $ShowStores['Category'];
			$Longitude = $ShowStores['Longitude'];
			$Latitude = $ShowStores['Latitude'];
			$Featured = $ShowStores['featured'];
			$PastFeatured = $ShowStores['pastfeatured'];
			$DirectionAddress = "$Address, $City, $State, $ListingZip";
			$DirectionAddress = urlencode($DirectionAddress);
			$Miles = null;
			if( !empty($ShowStores['distance']) ) {
				$Miles = $ShowStores['distance'];
			}

			$str .= '<div class="searchContainerCol"><p><b>'.$Name.'</b></p>';
			if ($Category <> "2") {
				$str .= "<p>$Discount</p>";
			}
			$str .= "<p>";
			if ($Category <> "2") {
				$str .= "$Address <br />";
			}
			if ($Category <> "2") {
				if ($Address2 <> "") {
					$str .= "$Address2 <br />";
				}
			}
			$str .= $City.",".$State."&nbsp;";
			if ($Category <> "2") {
				$str .= $ListingZip;
			}
			$str .= "<br />";
			if ($Category <> "2") {
				if ($Phone <> "") {
					$str .= $this->format_phone($Phone);
				}
				$str .= "<br />";
				if ($Website <> "") {
					$str .= "<a href=http://$Website target=_blank class=listingslink>$Website</a> <br>";
				}
			}
			$str .= "</p>";

			if ($Category <> "2") {
				$str .= '<p><a href="http://maps.google.com/maps?daddr='.$DirectionAddress.'"target="_blank" class="listingslink">Get Directions</a></p>';
			}
			if ($Category == "2") {
				$str .= '<p><a href="https://www.cigarrights.org/join.php?Type=GACS&MemType=Renew&Ref=" class="listingslinkupgrade">Upgrade to Platinum to show full listing</a></p>';
			}
			// If city or zip search then show distance
			if ($type == "cityOrZipSearch") {
				$str .= '<p>Distance to shop: <font color="#00CC00">'.round($Miles).' miles</font></p>';
			}
			// Showing category Image
			if ($Category == "1") {
				$str .= '<img src="'.site_url("/wp-content/plugins/cra/public/images/platinum_icon.jpg").'" />';
			}
			elseif ($Category == "2") {
				$str .= '<img src="'.site_url("/wp-content/plugins/cra/public/images/gold_icon.jpg").'" />';
			}
			elseif ($Category == "3") {
				$str .= '<img src="'.site_url("/wp-content/plugins/cra/public/images/business_icon.jpg").'" />';
			}

			// Showing Featured Image
			if ($Featured == "1") {
				$str .= "<p><img class='FeaturedPic' src='".site_url("/wp-content/plugins/cra/public/images/sotm.gif")."' /></p>";
			}
			// Showing Past Featured Image
			if ($PastFeatured == "1") {
				$str .= "<p><img class='PastFeaturedPic' src='".site_url("/wp-content/plugins/cra/public/images/sotm_past.gif")."' /></p>";
			}
			$str .= "<br/>";
			$str .= "</div>";
		}
		$str .= '</div>';
		$str .= '</div>';

		return $str;
	}

	/**
	* Search input container
	**/
	function searchHtml( $rm, $st, $ct, $zp ) {
	  // State Options
	  $stateOptions = "";
	  $allStates = $this->get_full_table_data("states");
	  foreach($allStates as $i => $d) {
	    if ( $st == $d['Short'] ) {
	      $stateOptions .= '<option value="'.$d['Short'].'" selected>'.$d['Short'].'</option>';
	    }
	    else {
	      $stateOptions .= '<option value="'.$d['Short'].'">'.$d['Short'].'</option>';
	    }
	  }

	  // Radius Options
	  $radiusOptions = "";
	  foreach ( array(10, 25, 50, 100) as $i => $radius ) {
	    if ( $rm == $radius ){
	      $radiusOptions .= '<option selected value="'.$radius.'">'.$radius.' Miles</option>';
	    }
	    else {
	      $radiusOptions .= '<option value="'.$radius.'">'.$radius.' Miles</option>';
	    }
	  }

	  // Radius Options
	  $categoriesOptions = "";
	  $categories = $this->get_full_table_data("categories");
	  foreach ( $categories as $i => $category ) {
	    if ( $category['CategoryID'] == $radius ){
	      $categoriesOptions .= '<option selected value="'.$category['CategoryID'].'">'.$category['CategoryName'].'</option>';
	    }
	    else {
	      $categoriesOptions .= '<option value="'.$category['CategoryID'].'">'.$category['CategoryName'].'</option>';
	    }
	  }

	  $str = '<table style="border:1px; border-color: #888888; border-style:solid;" cellpadding="0" cellspacing="0" id="searchbg">
	    <tr>
	        <td width="80%" align="center" valign="top">
	          <table width="100%" border="0" cellspacing="3" cellpadding="3">
	            <form name="thisForm" method="get" action="">
	              <input type="hidden" name="_submit_check" value="1"/>
	              <tr>
	                <td width="181" align="left" class="smallwhitebold">City:<br />
	                  <input class="smalltext" type="text" size="23" maxlength="250" name="City" value="'.$ct.'" />
	                </td>
	                <td width="97" align="left" class="smallwhitebold">State: <br />
	                  <select name="State" class="smalltext">'.$stateOptions.'</select>
	                </td>
	                <td width="84" align="left" class="smallwhitebold">OR</td>
	                <td colspan="2" align="left" class="smallwhitebold">Zip Code:<br />
	                  <input class="smalltext" type="text" size="23" maxlength="250" name="Zip" value="'.$zp.'" />
	                </td>
	               </tr>
	              <tr>
	                <td align="left" class="smallwhitebold">Within: <br />
	                  <select name="RadiusMiles" id="RadiusMiles" class="smalltext">'.$radiusOptions.'</select>
	                </td>
	                <td colspan="2" align="left" class="smallwhitebold">Category:<br />
	                  <select name="Category" class="smalltext">
	                    <option value="">&lt;All Types&gt;</option>
	                    '.$categoriesOptions.'
	                  </select>
	                </td>
	                <td width="64"><input type="submit" value="Search"></td>
	                <td width="140">&nbsp;</td>
	              </tr>
	            </form>
	          </table>
	        </td>
	        <td width="20%" align="center" valign="top"><img src="'.site_url('/wp-content/plugins/cra/public/images/poweredbyCF.jpg').'" border="0"/></td>
	      </tr>
	  </table>';
	  return $str;
	}

}
