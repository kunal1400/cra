<h1>Import Data From CSV</h1>
<hr/>
<p>This functionality allows you just upload a csv file in the "wp-content/plugins/cra/admin/csv" folder with same name as the mysql table name, then choose a file from dropdown and hit the import button.</p>

<form method="post" action="<?php echo admin_url() ?>admin.php?page=import_cra_listings_from_csv_folder">
  <table class="wp-list-table widefat fixed striped">
    <tr>
      <th>Choose File To Import</th>
      <td>
        <?php
        $plugin_dir = WP_PLUGIN_DIR . '/cra/admin/csv';
        $files = scandir($plugin_dir);
        echo "<select class='form-control' name='file_to_upload'>";
        foreach ($files as $i => $file) {
          if ( $file != "." && $file != ".." ) {
            $fileInfo = explode(".", $file);
            echo "<option value='".$fileInfo[0]."'>".$file."</option>";
          }
        }
        echo "</select>";
        ?>
      </td>
      <td>
        <input type="hidden" name="startImport" value="yes" />
        <button type="submit" class="button button-primary">Import Stores</button>
      </td>
    </tr>
  </table>
</form>