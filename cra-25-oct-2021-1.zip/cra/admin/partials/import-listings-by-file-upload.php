<h1>Import Data By CSV Upload</h1>
<hr/>

<form enctype='multipart/form-data' method="post" action="<?php echo admin_url() ?>admin.php?page=import_cra_store_by_file_upload">
  <table class="wp-list-table widefat fixed striped">
    <tr>
      <th>Choose File To Import Stores</th>
      <td>
        <input type="file" name="import_store_csv_file">        
      </td>
      <td>
        <button type="submit" class="button button-primary">Start Import</button>
      </td>
    </tr>
  </table>
</form>