<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       https://github.com/kunal1400/cra.git
 * @since      1.0.0
 *
 * @package    Cra
 * @subpackage Cra/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Cra
 * @subpackage Cra/admin
 * @author     Kunal Malviya <mark@bilmarctech.com>
 */
class Cra_Admin {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Cra_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Cra_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */
		 wp_enqueue_style( $this->plugin_name.'-jquery-admin-ui-css', plugin_dir_url( __FILE__ ) . 'css/jquery-ui.css', array(), $this->version, 'all' );
		 wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/cra-admin.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Cra_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Cra_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */
		 // wp_enqueue_script('jquery-ui-datepicker');
		 wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/cra-admin.js', array( 'jquery', 'jquery-ui-datepicker' ), $this->version, false );

	}

	public function import_stores( $file_to_upload, $filePath ) {
		global $table_prefix, $wpdb;
		$table_name = $table_prefix . "stores";		
		$file = fopen( $filePath, 'r' );

		// Variables to use
		$i = 0;
		$columns = "";
		$values = array();

		// Generating data to insert
		while( ($row = fgetcsv($file)) !== FALSE ) {
			if ( $i == 0 ) {
				$str = "";
				foreach ($row as $i => $column) {
					if ( $i > 0 ) {
						$str .= ",";
					}
					$str .= "`".$column."`";
				}
				$columns = "(".$str.")";
			}
			else {
				$cStr = "";
				foreach ($row as $i => $column) {
					if ( $i > 0 ) {
						$cStr .= ",";
					}

					// // If column is number then don't quote it around quotes
					// if ( is_numeric($column) ) {
					// 	$cStr .= $column;
					// }
					// else {
					// }
					$cStr .= "'".addslashes($column)."'";
				}
				$values[] = "(" . $cStr . ")";
			}
			$i++;
		}
		fclose($file);

		$sql = "INSERT INTO `$table_prefix".$file_to_upload."` $columns VALUES " . implode(",", $values);
		$queryResponse = $wpdb->query($sql);

		echo "<pre>";
		print_r($queryResponse);
		echo "</pre>";
	
	}

	public function admin_init_cb() {
		global $table_prefix, $wpdb;
		$table_name = $table_prefix . "stores";

		// Execution after import start
		if ( !empty($_POST['startImport']) && !empty($_POST['file_to_upload']) ) {
			$a = __DIR__ . '/csv/'.$_POST['file_to_upload'].'.csv';
			$this->import_stores($_POST['file_to_upload'], $a);
		}

		// Execution if store is added/edited
		if ( !empty($_POST['store_listing_form_submitted']) && !empty($_POST['store']) ) {
			if ( !empty($_POST['store_id_to_update']) ) {
				$addStoreRes = $wpdb->update($table_name, $_POST['store'], array('StoreID'=>$_POST['store_id_to_update']) );
				// Showing alret notices
				add_action( 'admin_notices', function($addStoreRes) {
					?>
			    <div class="notice notice-success is-dismissible">
			    	<p> Successfully Updated Store: <?php var_dump($addStoreRes); ?></p>
			    </div>
			    <?php
				});
			}
			else {
				$addStoreRes = $wpdb->insert($table_name, $_POST['store']);

				// Showing alret notices
				add_action( 'admin_notices', function($addStoreRes) {
					?>
			    <div class="notice notice-success is-dismissible">
			    	<p> Successfully Added Store: <?php var_dump($addStoreRes); ?></p>
			    </div>
			    <?php
				});
			}
		}

		// Exection if store is deleted
		if ( !empty($_GET['deleteStoreId']) ) {
			$wpdb->delete( $table_name, array('StoreID'=>$_GET['deleteStoreId']) );
		}

		// Execution of Bulk Action
		if ( !empty($_POST['storeToDelete']) && is_array($_POST['storeToDelete']) && count($_POST['storeToDelete']) > 0 ) {
			$idsToDelete = implode(",", $_POST['storeToDelete']);
			$sql = "DELETE FROM $table_name WHERE StoreID IN ($idsToDelete)";
			$deleteResponse = $wpdb->query($sql);
		}

		// If store csv file is upload
		if ( !empty($_FILES['import_store_csv_file']) ) {
			$this->import_stores( 'stores', $_FILES['import_store_csv_file']['tmp_name'] );
		}

	}

	/**
	* This function is rendering the settings page of plugin
	**/
	public function ph_infinite_add_menu() {
		$menu_slug 	= 'cra_settings';
		$menu_name 	= 'CRA';
		$menu_main 	= 'CRA Listings';
		add_menu_page($menu_name, $menu_main, 'manage_options', $menu_slug, '',plugin_dir_url(__FILE__).'assets/img/logo-wp.png', 57);
		add_submenu_page( $menu_slug, $menu_name, $menu_main, 'manage_options', $menu_slug, array($this, 'infi_settings'));
		add_submenu_page( $menu_slug, $menu_name, 'Add CRA', 'manage_options', 'add_cra_listings', array($this, 'add_cra_listings'));
		add_submenu_page( $menu_slug, $menu_name, 'Import Listings From CSV Folder', 'manage_options', 'import_cra_listings_from_csv_folder', array($this, 'import_listings'));
		add_submenu_page( $menu_slug, $menu_name, 'Import Listings By File Upload', 'manage_options', 'import_cra_store_by_file_upload', array($this, 'import_listings_by_file_upload'));
	}

	public function infi_settings() {
		global $table_prefix, $wpdb;
		$table_name = $table_prefix . "stores";		

		$pagenum = isset( $_GET['pagenum'] ) ? absint( $_GET['pagenum'] ) : 1;
	    $limit = 20; // number of rows in page
	    $offset = ( $pagenum - 1 ) * $limit;
	    
		if ( !empty($_POST['search_by_store_name']) ) {
			// Record count query
			$recordCount = "SELECT count(*) as total from $table_name WHERE Name like '%".$_POST['search_by_store_name']."%' ";

			// Records query
			$records = "SELECT * from $table_name WHERE Name like '%".$_POST['search_by_store_name']."%' ORDER BY StoreID DESC limit  $offset, $limit";
		}		
		else {
			// Record count query
			$recordCount = "SELECT count(*) as total from $table_name";

			// Records query
			if( isset($_GET['sort_by']) ) {
				$sortKeyOrder = $_GET['sort_by'].'Isdesc';
				if ( isset($_GET[$sortKeyOrder]) ) {
					$records = "SELECT * from $table_name ORDER BY ".$_GET['sort_by']." DESC limit  $offset, $limit";
				}
				else {
					$records = "SELECT * from $table_name ORDER BY ".$_GET['sort_by']." ASC limit  $offset, $limit";
				}
			}
			else {
				$records = "SELECT * from $table_name ORDER BY StoreID DESC limit  $offset, $limit";
			}
		}		

		$total = $wpdb->get_var( $recordCount );
	    $num_of_pages = ceil( $total / $limit );
	    $results = $wpdb->get_results( $records, ARRAY_A );

	    $rowcount = $wpdb->num_rows;
		$page_links = paginate_links( array(
			'base' => add_query_arg( 'pagenum', '%#%' ),
			'format' => '',
			'prev_text' => __( '&laquo;', 'text-domain' ),
			'next_text' => __( '&raquo;', 'text-domain' ),
			'total' => $num_of_pages,
			'current' => $pagenum
		));

		// $results = $wpdb->get_results("SELECT * FROM $table_name ORDER BY StoreID DESC LIMIT 0, 20", ARRAY_A);
		include 'partials/list_stores.php';
	}

	public function import_listings() {
		include 'partials/import-listings.php';
	}

	public function import_listings_by_file_upload() {
		include 'partials/import-listings-by-file-upload.php';
	}

	public function add_cra_listings() {
		global $table_prefix, $wpdb;
		$table_name = $table_prefix . "stores";
		$StoreID = ""; $Name = ""; $Address = ""; $Address2 = ""; $City = ""; $State = ""; $Zip = ""; $Phone = ""; $Website = ""; $Discount = "";
		$Category = ""; $Status = ""; $Longitude = ""; $Latitude = ""; $featured = ""; $pastfeatured = ""; $expiration = "";
		$LastUpdate = ""; $LastUser = "";

		// Getting all states
		$statesTableName = $wpdb->prefix.'states';
		$states = $wpdb->get_results("SELECT * FROM $statesTableName", ARRAY_A);

		// Getting all categories
		$categoriesTableName = $wpdb->prefix.'categories';
		$categories = $wpdb->get_results("SELECT * FROM $categoriesTableName", ARRAY_A);

		if ( !empty($_GET['storeId']) ) {
			$storeData = $wpdb->get_row("SELECT * FROM $table_name WHERE StoreID =".$_GET['storeId'], ARRAY_A);
			extract($storeData);
		}

		include 'partials/add_listing.php';
	}

}
